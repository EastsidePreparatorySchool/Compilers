/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilers;

import java.io.IOException;
import recursivedescentparser.Main;

/**
 *
 * @author gmein
 */
public class Compilers {

    public static void main(String[] args) throws IOException {
        Main.main(args);
    }

}
