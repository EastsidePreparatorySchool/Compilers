/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilers;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import lol.LOLcodeLexer;
import lol.LOLcodeParser;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import vx86.Program;
import vx86.Util;

/**
 *
 * @author gmein
 */
public class Compiler {

    public static boolean dataflow = false;

    static Program compile(InputStream is) throws IOException {
        int length;

        CharStream cs = CharStreams.fromStream(is);
        LOLcodeLexer lexer = new LOLcodeLexer(cs);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        LOLcodeParser parser = new LOLcodeParser(tokens);

        LOLcodeParser.ProgramContext tree = Parser.parse(lexer, parser, tokens);
        if (tree == null) {
            return null;
        }
        Util.println("Parsing successful.");

        // dump parse tree
        Dumper dumper = new Dumper();
        ParseTreeWalker.DEFAULT.walk(dumper, tree);
        System.out.println("\n\n");

   
        return null;
    }
}
