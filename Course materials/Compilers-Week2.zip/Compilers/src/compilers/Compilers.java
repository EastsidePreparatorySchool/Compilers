/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilers;

import java.io.IOException;
import vx86.Examples;
import vx86.Program;
import vx86.Util;
import vx86.Vx86;

/**
 *
 * @author gmein
 */
public class Compilers {

    public static void main(String[] args) throws IOException {
        Util.debugOn();

        Program p = Compiler.compile(Compilers.class.getResourceAsStream("example1.lol"));
    }

}
