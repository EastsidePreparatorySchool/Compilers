// Generated from c:\Users\gmein\Documents\GitHub\eps\AP-Compilers\Compilers\src\lol\LOLcode.g4 by ANTLR 4.7.1

   package lol;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LOLcodeParser}.
 */
public interface LOLcodeListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#literal_value}.
	 * @param ctx the parse tree
	 */
	void enterLiteral_value(LOLcodeParser.Literal_valueContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#literal_value}.
	 * @param ctx the parse tree
	 */
	void exitLiteral_value(LOLcodeParser.Literal_valueContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(LOLcodeParser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(LOLcodeParser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#vartype}.
	 * @param ctx the parse tree
	 */
	void enterVartype(LOLcodeParser.VartypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#vartype}.
	 * @param ctx the parse tree
	 */
	void exitVartype(LOLcodeParser.VartypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(LOLcodeParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(LOLcodeParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#separator}.
	 * @param ctx the parse tree
	 */
	void enterSeparator(LOLcodeParser.SeparatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#separator}.
	 * @param ctx the parse tree
	 */
	void exitSeparator(LOLcodeParser.SeparatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(LOLcodeParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(LOLcodeParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link LOLcodeParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(LOLcodeParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link LOLcodeParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(LOLcodeParser.ProgramContext ctx);
}