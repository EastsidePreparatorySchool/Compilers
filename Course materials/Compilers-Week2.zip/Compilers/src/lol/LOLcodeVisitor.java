// Generated from c:\Users\gmein\Documents\GitHub\eps\AP-Compilers\Compilers\src\lol\LOLcode.g4 by ANTLR 4.7.1

   package lol;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link LOLcodeParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface LOLcodeVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#literal_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral_value(LOLcodeParser.Literal_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtom(LOLcodeParser.AtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#vartype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVartype(LOLcodeParser.VartypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(LOLcodeParser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#separator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeparator(LOLcodeParser.SeparatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(LOLcodeParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link LOLcodeParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(LOLcodeParser.ProgramContext ctx);
}