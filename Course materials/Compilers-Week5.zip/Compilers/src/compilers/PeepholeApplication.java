/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilers;

import java.util.LinkedList;
import vx86.Instruction;
import vx86.Vx86;

/**
 *
 * @author gmein
 */
public class PeepholeApplication {

    public String name;
    public PeepholeEngine.Pattern pattern;
    public PeepholeEngine.Pattern substitution;
    public int lineOfInterest = -1;

    PeepholeApplication(String name) {
        this.name = name;
    }

    public static LinkedList<PeepholeApplication> generateAllPatterns() {
        LinkedList<PeepholeApplication> list = new LinkedList<>();
        //
        // note: patterns will be applied in order listed here
        // so, you really want to run push/pop before you run push x/pop y
        //
        list.add(generateXXXEBXImmediatePattern());
        list.add(generatePushPopPattern());
        return list;
    }

    public static PeepholeApplication generateXXXEBXImmediatePattern() {
        /*
        we don't really need to load EBX just to do something with the value and EAX:
           
        MOV  EAX,[8]             
        MOV  EBX,*-1*              
        *XXX*  EAX,EBX          
        
        becomes
           
        CMP  EAX,*-1*      
        
        could do this with an extension of data flow, but that is hard. so let's get it here:
         */

        PeepholeApplication pa = new PeepholeApplication("xxxEBXLoadingPattern");
        PeepholeEngine.Pattern pt = new PeepholeEngine.Pattern();

        pt.add(new Instruction(Vx86.Inx.MOV, Vx86.Mode.REGISTER, Vx86.Reg.EBX, Vx86.Mode.THAT, Vx86.Reg.THAT, "THAT"));
        pt.add(new Instruction(Vx86.Inx.THIS, Vx86.Mode.REGISTER, Vx86.Reg.EAX, Vx86.Mode.REGISTER, Vx86.Reg.EBX, 0));
        pa.pattern = pt;

        // careful not to have any ANY in this pattern, and THIS and THAT only if you supply them from the search pattern
        PeepholeEngine.Pattern sub = new PeepholeEngine.Pattern();
        sub.add(new Instruction(Vx86.Inx.THIS, Vx86.Mode.REGISTER, Vx86.Reg.EAX, Vx86.Mode.THAT, Vx86.Reg.THAT, "THAT"));
        pa.substitution = sub;

        //pa.lineOfInterest = 85;
        
        return pa;
    }


    public static PeepholeApplication generatePushPopPattern() {
        /*
        we don't like push exx/pop exx, it is stupid
        data flow analysis will fix this too, but anyway here is the example
         */

        PeepholeApplication pa = new PeepholeApplication("pushPopPattern");
        PeepholeEngine.Pattern pt = new PeepholeEngine.Pattern();

        // using THIS to make sure it is really the same operand being pushed and popped
        pt.add(new Instruction(Vx86.Inx.PUSH, Vx86.Mode.THIS, Vx86.Reg.THIS, Vx86.Mode.NONE, Vx86.Reg.NONE, "THIS"));
        pt.add(new Instruction(Vx86.Inx.POP, Vx86.Mode.THIS, Vx86.Reg.THIS, Vx86.Mode.NONE, Vx86.Reg.NONE, "THIS"));
        pa.pattern = pt;

        PeepholeEngine.Pattern sub = new PeepholeEngine.Pattern();
        // no substitution code for this one - empty pattern - just want it gone
        pa.substitution = sub;

        return pa;
    }
}
